module.exports = function(user) {
    var html = "<div>"+
                    +"<div style='width: 100%; padding: 10px'>"+
                        +"<h1>Verify your email address</h1>"+
                        +"<img src = 'https://1000logos.net/wp-content/uploads/2017/11/Zillow-Logo-500x150.png'> "+
                    +"</div>"+
                    +"<div>"+
                        +"<p>We at Freelancer.com take the trust and safety of our users seriously. We just need you to verify your email address by clicking the button below:</p>"+
                    +"</div>"+
                +"</div>";
    return html;
}
